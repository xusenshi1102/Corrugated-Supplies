# Blister > 2024-08-04 10:16pm
https://universe.roboflow.com/xusenshi/blister-ewc7o

Provided by a Roboflow user
License: CC BY 4.0

